# Fase 1 — affidabilità, versione 0.5.6

Preparata il **21 ottobre 2026**. Installazione sul sito e prove remote di
questa versione **non eseguite né confermate**. Nessun addebito, rimborso,
documento FIC, invio email o invio SDI è stato effettuato durante lo sviluppo.

## Cosa cambia

- Quando manca un elenco utilizzabile nella risposta PayPal, il recupero in
  coda attende e riprova: massimo sei elaborazioni, con attese di 60, 120, 300,
  600 e 1800 secondi dopo la prima. Sono tempi minimi: dipendono dal cron.
  Liste con più pagine, incassi ambigui, rimborsi, importi/valute incoerenti e
  stati sconosciuti restano bloccati. Nessun dato incompleto autorizza una fattura.
- Nella sezione 5, **Confronta letture PayPal (sola lettura)** legge un ordine
  esistente tramite SELECT, poi l'abbonamento e due volte le transazioni.
  Le due letture usano la stessa finestra, un'ora prima/dopo la creazione
  dell'abbonamento, con date `Z` e `+00:00`. Funziona anche per l'ordine 56 già
  fatturato. Non usa il costruttore `MemberOrder`, non associa ID e non salva ordini.
- **Programma prova cron senza fatture** programma un evento dedicato dopo
  un minuto e registra il suo orario di esecuzione. Non richiama il worker FIC.
- Il recupero FIC mantiene il limite di cinque pagine da 100 documenti, ma
  ora rifiuta anche una singola corrispondenza se la scansione è incompleta.
  Tiene conto delle pagine successive dichiarate dall'API; pagine incoerenti,
  righe non valide e ID ripetuti richiedono un'altra verifica. Nessun esito
  negativo libera il journal o autorizza un nuovo POST.

Restano conservati configurazione, autorizzazione della coda, copie fiscali,
associazioni e marker precedenti. Non occorre riattivare la coda se non si
cambiano le impostazioni. Le novità dell'oggetto della 0.5.5 sono incluse.

## Primo collaudo: nessun nuovo acquisto

1. Installare l'intero ZIP **fatture-in-cloud-sync-0.5.6.zip** sostituendo la
   versione precedente. Verificare **0.5.6** nell'elenco Plugin. Non cambiare
   azienda FIC, token, conto, gateway o piani per questa prova.
2. In **Impostazioni → PMPro Fatture in Cloud → sezione 5**, attivare la
   diagnostica per 60 minuti. Se il registro da 1 MB è pieno, conservarne una
   copia e archiviarlo tramite l'accesso ai file prima di riattivarla.
3. Inserire **56** nel nuovo campo ID ordine della sezione 5 e premere
   **Confronta letture PayPal (sola lettura)**. Non usare i pulsanti di creazione
   o recupero dell'associazione della sezione 3 per questo test.
4. Atteso: due letture con stessi istanti e suffissi diversi, stato ordine,
   stato abbonamento e presenza ID incasso separati. Se il pagamento storico è
   ancora disponibile e invariato, dovrebbe comparire `4VX44692N0631661Y`,
   `841.80 EUR`, `COMPLETED`. Un risultato diverso è un dato da analizzare,
   non un motivo per rifare il pagamento. L'ordine 56 e l'associazione al
   documento **560063390** devono restare invariati.
5. Scaricare il registro diagnostico e disattivare la diagnostica. Il riepilogo
   contiene solo campi selezionati; non condividere esportazioni PayPal grezze
   o credenziali. Annotare anche versioni WordPress, PMPro e addon PayPal.

Il confronto usa il risultato già decodificato dal gateway: non attribuisce
un HTTP 200 a tale risultato. Il log passivo, se attivo, osserva separatamente
gli esiti HTTP effettivi con contesto `diagnostic_comparison`. OAuth può
rinnovare il token in cache tramite POST di autenticazione: nessuna chiamata
di addebito, rimborso, modifica o creazione dell'abbonamento è prevista.

Le letture sono successive, non simultanee. Se coincidono oggi, non dimostrano
la causa della risposta incompleta del 14 ottobre; se differiscono, vanno
confrontati tempi, struttura e risposte di trasporto. L'API ammette entrambi
i formati. Per una diagnosi storica conclusiva servono le osservazioni del
momento dell'anomalia o una nuova ricorrenza spontanea, senza provocare addebiti.

## Cron: configurazione preparata, non applicata

La configurazione locale indica **SFTP OVH, porta 22**, percorso relativo
`www/wp-content/` e caricamento automatico disattivato. Sono presenti campi
di autenticazione, non riprodotti nella documentazione. Questo non prova
accesso SSH a una shell, accesso al Manager OVH o una connessione riuscita.
In questa sessione non sono stati letti il database, `wp-config.php` remoto,
la configurazione cron o i file del server tramite una sessione autenticata.

Mancano: nome del piano OVH, disponibilità della scheda Cron nel Manager,
eventuale scheduler già attivo e valore attuale di `DISABLE_WP_CRON`.
L'utente ha risposto che deve controllare e al momento non conosce questi dati.
Non disabilitare il cron da visite prima di aver verificato il sostituto.

### Se è hosting Web OVH condiviso

1. Manager OVH → **Web Cloud → Hosting → hosting del sito → Altro → Cron**.
   Controllare prima l'elenco delle operazioni esistenti, evitando doppioni.
2. La documentazione OVH prevede al massimo una partenza all'ora e non
   permette di scegliere il minuto. È indipendente dalle visite, ma non
   garantisce il completamento della coda in circa due minuti.
3. Per l'opzione oraria, verificare via SFTP la presenza di `wp-cron.php`
   nella radice WordPress. Il candidato ricavato dalla configurazione locale
   è `www/wp-cron.php`: **non è un percorso remoto verificato**. Usare nel
   Manager il percorso relativo effettivo, selezionare una versione PHP
   compatibile con il sito, frequenza ogni ora e conservare i log Cron.
4. Per l'obiettivo di 1–2 minuti, usare uno scheduler HTTPS disponibile su
   un servizio/server sempre acceso, oppure un cron di sistema se il piano
   lo permette. Occorre individuare il servizio effettivo prima di attivarlo.

### Se è disponibile uno scheduler HTTPS o un server con cron di sistema

Configurazione da applicare al servizio scelto:

| Campo | Valore |
| --- | --- |
| Metodo | GET |
| URL WordPress da verificare | `https://inplaycetools.com/wp-cron.php` |
| Frequenza | Ogni 2 minuti |
| TLS | Verifica certificato attiva |
| Redirect | Non seguire redirect inattesi a login o altri host |
| Monitoraggio | Conservare orario, HTTP status ed errori; segnalare fallimenti ripetuti |

Esempio **non eseguito**, solo dopo aver verificato `command -v curl` sul
server che ospita lo scheduler:

```cron
*/2 * * * * curl --fail --silent --show-error --connect-timeout 10 --max-time 55 --output /dev/null https://inplaycetools.com/wp-cron.php
```

L'URL va verificato rispetto alla radice WordPress reale. L'esecuzione di
`wp-cron.php` può elaborare **tutti i lavori scaduti di WordPress**, inclusi
quelli FIC già autorizzati: soltanto l'evento diagnostico è privo di fatture.
Non creare endpoint PHP personalizzati pubblici e non passare token FIC/PayPal
allo scheduler. Se si usa WP-CLI invece di `wp-cron.php`, va verificato il
contesto `DOING_CRON`: il worker attuale lo richiede per l'esecuzione anonima.

### Verifica senza visite

1. Dopo aver attivato il servizio, in sezione 5 premere **Programma prova cron
   senza fatture**. Annotare la scadenza UTC mostrata.
2. Chiudere tutte le pagine del sito. Attendere almeno due intervalli dello
   scheduler: almeno quattro minuti per la frequenza di due minuti; oltre
   due ore per quella oraria.
3. Leggere i log del servizio prima di riaprire il sito, poi annotare l'ora
   della prima riapertura. Il pannello deve riportare **Eseguita UTC** con
   orario precedente alla riapertura e coerente con i log. Il 21 ottobre
   2026 Europe/Rome è UTC+2.
4. HTTP 200 da solo non prova l'elaborazione. Se l'evento parte soltanto
   alla riapertura, l'indipendenza dalle visite non è dimostrata; anche
   traffico di terzi può attivare WP-Cron. Solo dopo la prima verifica,
   configurare una singola definizione `define('DISABLE_WP_CRON', true);`
   nel `wp-config.php` effettivo prima del caricamento di WordPress e ripetere
   la prova, controllando i log esterni. In caso di problemi, ripristinare
   il precedente valore e verificare il servizio.
5. Ripetere la prova in un secondo intervallo e monitorare gli errori dello
   scheduler: un singolo evento riuscito non dimostra la regolarità futura.

## Limite di recupero FIC e passi ancora aperti

Il limite di 500 documenti non è stato eliminato aumentando indefinitamente
le chiamate. Se la quinta pagina è piena e non certifica la fine dell'elenco,
il plugin restituisce `recovery_scan_limit` anche se ha trovato un marker.
I metadati di paginazione permettono invece di riconoscere una quinta pagina
finale. Una scansione senza corrispondenze conserva il blocco.

Per un tentativo incerto oltre il limite: annotare ordine e marker del
journal, cercare in FIC il riferimento esatto nelle note o nel vecchio oggetto,
confrontare azienda, totale e duplicati. Non cancellare lock/journal per
forzare la creazione. L'associazione assistita per documenti fuori dalla
scansione e una ricerca paginata riprendibile sono ancora da implementare;
richiedono controllo delle pagine che cambiano durante la scansione e dei
limiti API. Non è stata introdotta una ricerca per descrizione del piano.

Prima dei rinnovi restano inoltre: collaudo reale della concorrenza su
WordPress/MySQL, monitoraggio dei lavori persi/interrotti oltre gli ultimi
20 mostrati, verifica degli incassi anche quando l'ID è già presente e una
chiave persistente univoca per **incasso**, oltre al lock attuale per ordine.
I test simulati non provano una garanzia globale fra processi MySQL reali.
Questa release non gestisce rinnovi, rimborsi, note di credito, area fatture,
email di disponibilità o invio SDI; le successive fasi restano ordinate come
richiesto. L'inventario email esistente resta il riferimento per la fase 4.

## Registro di questa fase

| Controllo | Esito |
| --- | --- |
| Acquisti Gold/Professional, documenti 8/TEST e 9/TEST, 21 ottobre | Confermati dall'utente prima di questa sessione; non ripetuti |
| ID PMPro/FIC dei due acquisti | Non comunicati |
| Installazione 0.5.5 | Non confermata |
| Preparazione e test locali 0.5.6 | Completati; dettagli nel README |
| Installazione 0.5.6 e conservazione impostazioni | Da eseguire |
| Confronto di sola lettura sull'ordine 56 | Preparato, non eseguito sul sito |
| Configurazione e regolarità cron esterno | Da verificare/applicare con accesso al servizio |
| Causa storica della risposta PayPal incompleta | Non accertata |

## Riferimenti ufficiali consultati

- [PayPal: transazioni dell'abbonamento e formati data](https://developer.paypal.com/api/subscriptions/v1/subscriptions-transactions).
- [Gateway PMPro PayPal: configurazione e webhook](https://www.paidmembershipspro.com/add-ons/pmpro-paypal/).
- [Client API PMPro, ramo dev consultato](https://github.com/strangerstudios/pmpro-paypal/blob/dev/classes/class-paypal-api.php),
  confrontato con il tag 1.1.4: i due metodi usati effettuano GET; il rinnovo
  del token usa OAuth. Il ramo dev non identifica la versione sul sito.
- [Handler PMPro PayPal consultato](https://github.com/strangerstudios/pmpro-paypal/blob/dev/includes/webhook-handler.php):
  l'attivazione può ancora completare il checkout senza ID incasso;
  `PAYMENT.SALE.COMPLETED` delega al gestore ricorrente PMPro.
- [WordPress: evento singolo](https://developer.wordpress.org/reference/functions/wp_schedule_single_event/)
  e [scheduler di sistema](https://developer.wordpress.org/plugins/cron/hooking-wp-cron-into-the-system-task-scheduler/).
- [OVH: configurazione e limiti del cron Web Hosting](https://docs.ovhcloud.com/it/guides/web-cloud/web-hosting/cron-tasks).
- [FIC OpenAPI: elenco documenti e paginazione](https://github.com/fattureincloud/openapi-fattureincloud/blob/master/openapi.yaml).
